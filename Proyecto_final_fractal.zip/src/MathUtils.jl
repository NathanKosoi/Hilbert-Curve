
# Número aleatorio entre a y b, a y b reales.
randab(a,b) = (b-a)*rand()+a

# Constante de prueba
my_const_test = 42

